package com.LaptopManagementSystem.Database;

import java.io.FileNotFoundException;
import java.io.IOException;

import com.LaptopManagementSystem.Exception.PersonException;

public interface ILaptopDAO {
	public void Account_Validation(String un, String pwd, int option) throws FileNotFoundException, IOException, PersonException;
}
