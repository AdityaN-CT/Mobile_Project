package com.LaptopManagementSystem.Database;

import java.io.FileNotFoundException;
import java.io.IOException;

import com.LaptopManagementSystem.Exception.PersonException;
import com.LaptopManagementSystem.model.Laptop;

public interface ILaptopDAO {
	public void Account_Validation(String un, String pwd, int option) throws FileNotFoundException, IOException, PersonException;

	public void Add_Laptop(Laptop lp_obj) throws FileNotFoundException, IOException;

	public Object Search_Mobile(String iD) throws FileNotFoundException, PersonException, IOException;

	public Object display_all();
	
}
