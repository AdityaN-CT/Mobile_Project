package com.LaptopManagementSystem.Database;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Properties;

import com.LaptopManagementSystem.Exception.PersonException;
import com.LaptopManagementSystem.model.Laptop;

public class LaptopDAOImpl implements ILaptopDAO {
	FileInputStream fis;
	OutputStream fout;
	@Override
	public void Account_Validation(String un, String pwd, int option) throws IOException,  PersonException {
		
		Properties prop = new Properties();
		if (option == 1) {
			fis = new FileInputStream("E:\\JAVA\\LaptopManagementSystem\\src\\Admin_Login.properties");
			prop.load(fis);
			if(prop.containsKey(un)) {
				if (!pwd.equals(prop.get(un))) 
					//System.out.println(prop.getProperty(un));
					//System.out.println(pwd);
					throw new PersonException("Invalid Password");
				
			}
			else {
				throw new PersonException("Invalid Username");
		
			}
		
		}
		else {
			fis = new FileInputStream("E:\\JAVA\\LaptopManagementSystem\\src\\Customer_Login.properties");
			prop.load(fis);
			if(prop.containsKey(un)) {
				if (!pwd.equals(prop.get(un))) 
					//System.out.println(prop.getProperty(un));
					//System.out.println(pwd);
					throw new PersonException("Invalid Password");
				
			}
			else {
				throw new PersonException("Invalid Username");
		
			}
		
		
		}
		
		
	}

	@Override
	public void Add_Laptop(Laptop lp_obj) throws IOException {
		fout = new FileOutputStream("E:\\JAVA\\LaptopManagementSystem\\src\\LaptopDetails.properties", true);
		Properties prop = new Properties();
		prop.setProperty(String.valueOf(lp_obj.getLaptop_ID()), lp_obj.getName() + " " + lp_obj.getRAM() + " " + lp_obj.getStorage() + " " +lp_obj.getPrice());
		prop.store(fout, null);
		
	}

	@Override
	public Object Search_Mobile(String ID) throws PersonException, IOException {
		fis = new FileInputStream("E:\\JAVA\\LaptopManagementSystem\\src\\LaptopDetails.properties");
		Properties prop = new Properties();
		prop.load(fis);
		if (!prop.containsKey(ID)) {
			throw new PersonException("Does Not Exist");
		}
		else {
			return prop.get(ID);
		}
	
	}

	@Override
	public Object display_all() {
		return fis;

		
	}

}
