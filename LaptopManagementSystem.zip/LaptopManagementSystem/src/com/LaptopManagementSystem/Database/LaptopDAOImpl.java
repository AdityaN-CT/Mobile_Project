package com.LaptopManagementSystem.Database;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import com.LaptopManagementSystem.Exception.PersonException;

public class LaptopDAOImpl implements ILaptopDAO {

	@Override
	public void Account_Validation(String un, String pwd, int option) throws IOException,  PersonException {
		FileInputStream fis;
		Properties prop = new Properties();
		if (option == 1) {
			fis = new FileInputStream("C:\\Users\\AdityaN\\Desktop\\Java\\LaptopManagementSystem\\src\\Admin_Login.properties");
			prop.load(fis);
			if(prop.containsKey(un)) {
				if (!pwd.equals(prop.get(un))) 
					//System.out.println(prop.getProperty(un));
					//System.out.println(pwd);
					throw new PersonException("Invalid Password");
				
			}
			else {
				throw new PersonException("Invalid Username");
			}
		
		}
		
		
	}

}
