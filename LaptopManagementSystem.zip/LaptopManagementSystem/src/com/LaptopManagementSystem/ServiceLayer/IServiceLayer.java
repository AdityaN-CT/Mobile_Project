package com.LaptopManagementSystem.ServiceLayer;

import java.io.FileNotFoundException;
import java.io.IOException;

import com.LaptopManagementSystem.Exception.PersonException;

public interface IServiceLayer {
	public void Account_Validation(String un, String pwd, int option) throws FileNotFoundException, IOException, PersonException;
}
