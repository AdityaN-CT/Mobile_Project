package com.LaptopManagementSystem.ServiceLayer;

import java.io.FileNotFoundException;
import java.io.IOException;

import com.LaptopManagementSystem.Database.*;
import com.LaptopManagementSystem.Exception.PersonException;
import com.LaptopManagementSystem.model.Laptop;

public class ServiceLayerImpl implements IServiceLayer {
	ILaptopDAO ref = new LaptopDAOImpl();
	@Override
	public void Account_Validation(String un, String pwd, int option) throws FileNotFoundException, IOException, PersonException {
		ref.Account_Validation(un, pwd, option);
		
	}
	@Override
	public void Add_Laptop(Laptop lp_obj) throws IOException {
		ref.Add_Laptop(lp_obj);
		
	}
	@Override
	public Object Search_Mobile(String ID) throws PersonException, IOException {
		return ref.Search_Mobile(ID);
		
	}
	@Override
	public Object display_all() {
		
		return ref.display_all();
	}

}
