package com.LaptopManagementSystem.ServiceLayer;

import java.io.FileNotFoundException;
import java.io.IOException;

import com.LaptopManagementSystem.Database.*;
import com.LaptopManagementSystem.Exception.PersonException;

public class ServiceLayerImpl implements IServiceLayer {
	ILaptopDAO ref = new LaptopDAOImpl();
	@Override
	public void Account_Validation(String un, String pwd, int option) throws FileNotFoundException, IOException, PersonException {
		ref.Account_Validation(un, pwd, option);
		
	}

}
