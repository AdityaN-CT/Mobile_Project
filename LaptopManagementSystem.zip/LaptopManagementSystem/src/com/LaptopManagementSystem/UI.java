package com.LaptopManagementSystem;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;

import com.LaptopManagementSystem.Exception.PersonException;
import com.LaptopManagementSystem.ServiceLayer.*;
import com.LaptopManagementSystem.Exception.*;
public class UI {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		IServiceLayer ref = new ServiceLayerImpl();
		Scanner scn = new Scanner(System.in);
		System.out.println("Who are You?\n"
				+ "1. Admin\n"
				+ "2. Customer\n");
		
		switch(scn.nextInt()) {
		

		case 1:
			
		System.out.println("Username : ");
		String un = scn.next();
		System.out.println("Password : ");
		String pwd = scn.next();
		try {
			ref.Account_Validation(un, pwd, 1);
			System.out.println("Login Successful");
		}
		catch (PersonException p){
			System.out.println(p.getMessage()); 
		
		}
		System.out.println("Welcome to World Of Laptops \n"
				+ "1. Add Laptop \n"
				+ "2. Search By ID \n"
				+ "3. Display All Laptop\n"
				+ "4. Delete Laptop\n"
				+ "5. Exit\n");
			
		case 2:
			System.out.println("Welcome to World Of Laptops \n"
					+ "1. Display All Laptops\n"
					+ "2.Exit");
		

		
		
		
	}
	}
}
