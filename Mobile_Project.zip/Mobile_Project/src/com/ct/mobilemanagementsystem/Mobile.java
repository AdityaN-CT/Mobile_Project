package com.ct.mobilemanagementsystem;

public class Mobile {
	@Override
	public String toString() {
		return " [mobId=" + mobId + ", Brand_Name=" + Brand_Name + ", Description=" + Description
				+ ", RAM_Memory=" + RAM_Memory + ", Internal_Storage=" + Internal_Storage + ", Price=" + Price + "]";
	}

	private int mobId;
	private String Brand_Name;
	private String Description;
	private int RAM_Memory;
	private int Internal_Storage;
	private float Price;
	
	public void setData(int mobId, String BrandName, String description, int RAM, int InternalStorage, float Price) {
		this.mobId = mobId;
		this.Brand_Name = BrandName;
		this.Description = description;
		this.RAM_Memory = RAM;
		this.Internal_Storage = InternalStorage;
		this.Price = Price;
		
	}
	
	public String getData() {
		System.out.println("mobId:" +mobId + "\n Brand Name:" + Brand_Name);
		return "Mobile Located";
	}
	
}
