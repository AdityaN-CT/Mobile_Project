package com.ct.mobilemanagementsystem.UI;

import com.ct.mobilemanagementsystem.dao.*;

import java.util.*;
import com.ct.mobilemanagementsystem.*;
import com.ct.mobilemanagementsystem.service.*;
public class UI {
	static MobileServiceImpl S1 = new MobileServiceImpl();
	public static void main(String[] args) {
	while(true) {
	System.out.println("1.Add Mobile \n2.Search Mobiles by Id \n3.Display All Mobiles \n4.delete mobile \n5.exit");
	Scanner scn = new Scanner(System.in);
	int option = scn.nextInt();
	switch(option){
	case 1:
		System.out.println("Enter Data");
		int MobId = scn.nextInt();
		String Brand_Name = scn.next();
		String description = scn.next();
		int RAM = scn.nextInt();
		int Internal_Storage = scn.nextInt();
		float Price = scn.nextFloat();
		
		System.out.println(S1.validation(MobId, Brand_Name, description, RAM, Internal_Storage, Price));
		break;
	case 2:
		System.out.println("Enter ID");
		int ID = scn.nextInt();
		System.out.println(S1.find(ID));
		break;
		
	case 3:

			Collection displayMobiles = S1.displayAll();
			System.out.println(displayMobiles);
			break;
		 
	
	case 4:
		System.out.println("Enter ID to be deleted");
		int ID1 = scn.nextInt();
		System.out.println(S1.delete(ID1));
		break;
		
	case 5:
		System.exit(0);
	}

	}
	}

}
