package com.ct.mobilemanagementsystem.dao;

import java.util.*;

public interface IMobileDAO {
	 public void AddMobile(int mobID, String BrandName, String description, int RAM, int InternalStorage, float Price);
	 public String find(int mobID);
	 public String delete(int mobID); 
	 public Collection displayAll();
}
