package com.ct.mobilemanagementsystem.dao;
import com.ct.mobilemanagementsystem.*;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class MobileDAOImpl implements IMobileDAO{
	//static int i = 1;
	Map <Integer, Mobile>  mapper = new HashMap<>();
	Mobile M1 = new Mobile();
	public void AddMobile(int mobID, String BrandName, String description, int RAM, int InternalStorage, float Price){
	
	
	M1.setData(mobID, BrandName, description, RAM, InternalStorage, Price);

	

	//mapper.put(i, new M1(this.mobID, this.BrandName, this.description, this.RAM, this.InternalStorage, this.Price));

	mapper.put(mobID, M1);
	
	
	}
	public String find(int mobID) {
		
		System.out.println("mobid = " + mapper.containsKey(mobID));
		if (mapper.containsKey(mobID)) {
		M1 = mapper.get(mobID);
		return M1.getData();

		}
		else
			return "Mobile does not exist";
	}
	
	public String delete(int mobID) {
		if (mapper.containsKey(mobID)) {
		M1 = mapper.remove(mobID);
		return "Mobile deleted";

		}
		else
			return "Mobile does not exist";
		
		
	}
	
	public Collection displayAll() {
		return mapper.values();

}
}

