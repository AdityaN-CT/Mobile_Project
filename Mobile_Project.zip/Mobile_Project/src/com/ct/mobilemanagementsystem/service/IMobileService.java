package com.ct.mobilemanagementsystem.service;

import java.util.Collection;

public interface IMobileService {
	public String validation(int mobID, String BrandName, String description, int RAM, int InternalStorage, float Price);
	public String find(int mobID);
	public String delete(int mobID); 
	public Collection displayAll();

}
