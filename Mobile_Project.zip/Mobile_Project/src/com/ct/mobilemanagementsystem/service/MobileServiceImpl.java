package com.ct.mobilemanagementsystem.service;
import com.ct.mobilemanagementsystem.dao.*;
import java.util.*;

public class MobileServiceImpl implements IMobileService {
	static MobileDAOImpl A1 = new MobileDAOImpl();
	public static final List<String> brand = new ArrayList<String>(){{
		add("OnePlus");
		add("Samsung");
		add("Xiaomi");
		add("Oppo");
	}};
	
	@Override
	public String validation(int mobID, String BrandName, String description, int RAM, int InternalStorage, float Price) {
		if (mobID >= 100 && mobID <= 999 && brand.contains(BrandName)) {
			
			A1.AddMobile(mobID, BrandName, description, RAM, InternalStorage, Price);
			return "Mobile Added";
			
		}
		else
		{
			return "Not valid";
		}
		}
		
	public String find(int mobID) {
		
		return A1.find(mobID);
	}
	
	public String delete(int mobID)
	{
		return A1.delete(mobID);
		
	}
	
	public Collection displayAll() {
		return A1.displayAll();
	}
}
